class_name TouchButton
extends Control
## Round multi-touch button. Momentary or toggle. Knows nothing about gameplay.

signal pressed
signal released
signal toggled(is_on: bool)

@export var label_text: String = ""
@export var toggle_mode: bool = false
@export var idle_color: Color = Color(1.0, 1.0, 1.0, 0.2)
@export var active_color: Color = Color(1.0, 1.0, 1.0, 0.5)
@export var font_size: int = 22

var _finger: int = -1
var _is_down: bool = false
var _is_on: bool = false


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func _input(event: InputEvent) -> void:
    if not is_visible_in_tree():
        return
    var touch := event as InputEventScreenTouch
    if touch == null:
        return
    if touch.pressed:
        if _finger == -1 and _contains(touch.position):
            _finger = touch.index
            _is_down = true
            if toggle_mode:
                _is_on = not _is_on
                toggled.emit(_is_on)
            pressed.emit()
            queue_redraw()
            get_viewport().set_input_as_handled()
    elif touch.index == _finger:
        _finger = -1
        _is_down = false
        released.emit()
        queue_redraw()
        get_viewport().set_input_as_handled()


func _draw() -> void:
    var center: Vector2 = size * 0.5
    var radius: float = minf(size.x, size.y) * 0.5
    var lit: bool = _is_on if toggle_mode else _is_down
    draw_circle(center, radius, active_color if lit else idle_color)
    draw_arc(center, radius, 0.0, TAU, 48, Color(1.0, 1.0, 1.0, 0.4), 2.0)
    var font: Font = ThemeDB.fallback_font
    draw_string(font, Vector2(0.0, center.y + font_size * 0.35), label_text,
            HORIZONTAL_ALIGNMENT_CENTER, size.x, font_size)


func _contains(point: Vector2) -> bool:
    var center: Vector2 = global_position + size * 0.5
    return point.distance_to(center) <= minf(size.x, size.y) * 0.6
