extends CanvasLayer
## Lays out the touch widgets and forwards their signals to InputManager.
## Gameplay scripts never reference this scene.

@export var always_show: bool = true ## false = only on touchscreen devices

@onready var _look_area: CameraTouchArea = $Root/CameraArea
@onready var _joystick: SpiderVirtualJoystick = $Root/Joystick
@onready var _jump_button: TouchButton = $Root/JumpButton
@onready var _run_button: TouchButton = $Root/RunButton


func _ready() -> void:
    visible = always_show or DisplayServer.is_touchscreen_available()
    if not visible:
        process_mode = Node.PROCESS_MODE_DISABLED
        return

    _set_rect(_joystick, 0.0, 1.0, 50.0, -270.0, 270.0, -50.0)
    _set_rect(_jump_button, 1.0, 1.0, -200.0, -200.0, -70.0, -70.0)
    _set_rect(_run_button, 1.0, 1.0, -320.0, -130.0, -220.0, -30.0)

    _joystick.vector_changed.connect(InputManager.set_touch_move)
    _jump_button.pressed.connect(InputManager.request_jump)
    _run_button.toggled.connect(InputManager.set_touch_run)
    _look_area.look_delta.connect(InputManager.add_touch_look)


func _set_rect(control: Control, anchor_x: float, anchor_y: float,
        left: float, top: float, right: float, bottom: float) -> void:
    control.anchor_left = anchor_x
    control.anchor_right = anchor_x
    control.anchor_top = anchor_y
    control.anchor_bottom = anchor_y
    control.offset_left = left
    control.offset_top = top
    control.offset_right = right
    control.offset_bottom = bottom
