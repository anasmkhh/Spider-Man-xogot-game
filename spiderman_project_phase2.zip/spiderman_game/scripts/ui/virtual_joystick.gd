class_name SpiderVirtualJoystick
extends Control
## Fixed on-screen analog stick. Emits a Vector2 (x right, y down), length <= 1.
## Knows nothing about gameplay.

signal vector_changed(value: Vector2)

@export_range(0.0, 0.9) var dead_zone: float = 0.12
@export var base_color: Color = Color(1.0, 1.0, 1.0, 0.18)
@export var knob_color: Color = Color(1.0, 1.0, 1.0, 0.45)
@export_range(0.1, 0.8) var knob_ratio: float = 0.38

var _finger: int = -1
var _knob_offset: Vector2 = Vector2.ZERO


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func _input(event: InputEvent) -> void:
    if not is_visible_in_tree():
        return
    var touch := event as InputEventScreenTouch
    if touch != null:
        if touch.pressed:
            if _finger == -1 and _contains(touch.position):
                _finger = touch.index
                _update_from(touch.position)
                get_viewport().set_input_as_handled()
        elif touch.index == _finger:
            _release()
            get_viewport().set_input_as_handled()
        return
    var drag := event as InputEventScreenDrag
    if drag != null and drag.index == _finger:
        _update_from(drag.position)
        get_viewport().set_input_as_handled()


func _draw() -> void:
    var center: Vector2 = size * 0.5
    var radius: float = minf(size.x, size.y) * 0.5
    draw_circle(center, radius, base_color)
    draw_arc(center, radius, 0.0, TAU, 48, Color(1.0, 1.0, 1.0, 0.35), 2.0)
    draw_circle(center + _knob_offset, radius * knob_ratio, knob_color)


func _contains(point: Vector2) -> bool:
    var center: Vector2 = global_position + size * 0.5
    return point.distance_to(center) <= minf(size.x, size.y) * 0.6


func _update_from(point: Vector2) -> void:
    var center: Vector2 = global_position + size * 0.5
    var radius: float = minf(size.x, size.y) * 0.5
    var offset: Vector2 = (point - center).limit_length(radius)
    _knob_offset = offset
    var raw: Vector2 = offset / radius
    var value: Vector2 = Vector2.ZERO
    if raw.length() > dead_zone:
        value = raw.normalized() * ((raw.length() - dead_zone) / (1.0 - dead_zone))
    vector_changed.emit(value)
    queue_redraw()


func _release() -> void:
    _finger = -1
    _knob_offset = Vector2.ZERO
    vector_changed.emit(Vector2.ZERO)
    queue_redraw()
