class_name CameraTouchArea
extends Control
## Full-screen look area. Claims only touches no other widget handled
## (via _unhandled_input) and ignores the left part of the screen.

signal look_delta(relative: Vector2)

@export_range(0.0, 0.8) var left_dead_fraction: float = 0.35

var _finger: int = -1


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func _unhandled_input(event: InputEvent) -> void:
    if not is_visible_in_tree():
        return
    var touch := event as InputEventScreenTouch
    if touch != null:
        if touch.pressed:
            var min_x: float = global_position.x + size.x * left_dead_fraction
            if _finger == -1 and touch.position.x >= min_x:
                _finger = touch.index
        elif touch.index == _finger:
            _finger = -1
        return
    var drag := event as InputEventScreenDrag
    if drag != null and drag.index == _finger:
        look_delta.emit(drag.relative)
