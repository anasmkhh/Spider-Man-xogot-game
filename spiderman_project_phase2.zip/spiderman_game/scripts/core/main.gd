extends Node
## Game entry point. Applies global settings; owns no gameplay logic.

@export var settings: GameSettings


func _ready() -> void:
    if settings == null:
        settings = GameSettings.new()
    Engine.max_fps = settings.target_fps
    var rig := get_tree().get_first_node_in_group("camera_rig") as CameraRig
    if rig != null:
        rig.apply_settings(settings)
