extends Node
## Central input hub (autoload "InputManager").
## Merges keyboard, gamepad and touch input behind one small API so gameplay
## scripts never read raw devices or UI widgets directly.

signal jump_requested

const DEFAULT_DEADZONE: float = 0.2

var _touch_move: Vector2 = Vector2.ZERO
var _touch_look: Vector2 = Vector2.ZERO
var _touch_run: bool = false


func _ready() -> void:
    _register_default_actions()


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("jump"):
        jump_requested.emit()


# ---- Queried by gameplay ---------------------------------------------------

## Movement input. x = right, y = back (so forward is negative y). Length <= 1.
func get_move_vector() -> Vector2:
    if _touch_move.length_squared() > 0.0001:
        return _touch_move
    return Input.get_vector("move_left", "move_right", "move_forward", "move_back")


func is_run_held() -> bool:
    return _touch_run or Input.is_action_pressed("run")


## Analog look input (arrow keys / right stick), range -1..1.
func get_look_stick() -> Vector2:
    return Input.get_vector("look_left", "look_right", "look_up", "look_down")


## Accumulated touch-drag pixels since the last call.
func consume_touch_look() -> Vector2:
    var value: Vector2 = _touch_look
    _touch_look = Vector2.ZERO
    return value


# ---- Fed by the touch UI ---------------------------------------------------

func set_touch_move(value: Vector2) -> void:
    _touch_move = value.limit_length(1.0)


func add_touch_look(relative: Vector2) -> void:
    _touch_look += relative


func set_touch_run(is_on: bool) -> void:
    _touch_run = is_on


func request_jump() -> void:
    jump_requested.emit()


# ---- Action registration (no project.godot input map needed) ---------------

func _register_default_actions() -> void:
    _bind_key("move_forward", KEY_W)
    _bind_key("move_back", KEY_S)
    _bind_key("move_left", KEY_A)
    _bind_key("move_right", KEY_D)
    _bind_key("jump", KEY_SPACE)
    _bind_key("run", KEY_SHIFT)
    _bind_key("look_up", KEY_UP)
    _bind_key("look_down", KEY_DOWN)
    _bind_key("look_left", KEY_LEFT)
    _bind_key("look_right", KEY_RIGHT)

    _bind_axis("move_left", JOY_AXIS_LEFT_X, -1.0)
    _bind_axis("move_right", JOY_AXIS_LEFT_X, 1.0)
    _bind_axis("move_forward", JOY_AXIS_LEFT_Y, -1.0)
    _bind_axis("move_back", JOY_AXIS_LEFT_Y, 1.0)
    _bind_axis("look_left", JOY_AXIS_RIGHT_X, -1.0)
    _bind_axis("look_right", JOY_AXIS_RIGHT_X, 1.0)
    _bind_axis("look_up", JOY_AXIS_RIGHT_Y, -1.0)
    _bind_axis("look_down", JOY_AXIS_RIGHT_Y, 1.0)
    _bind_button("jump", JOY_BUTTON_A)
    _bind_button("run", JOY_BUTTON_RIGHT_SHOULDER)


func _ensure_action(action: StringName) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action, DEFAULT_DEADZONE)


func _bind_key(action: StringName, keycode: Key) -> void:
    _ensure_action(action)
    var event := InputEventKey.new()
    event.physical_keycode = keycode
    InputMap.action_add_event(action, event)


func _bind_axis(action: StringName, axis: JoyAxis, direction: float) -> void:
    _ensure_action(action)
    var event := InputEventJoypadMotion.new()
    event.axis = axis
    event.axis_value = direction
    InputMap.action_add_event(action, event)


func _bind_button(action: StringName, button: JoyButton) -> void:
    _ensure_action(action)
    var event := InputEventJoypadButton.new()
    event.button_index = button
    InputMap.action_add_event(action, event)
