class_name GameSettings
extends Resource
## Tunable, project-wide settings. Edit resources/settings/default_settings.tres.

@export var target_fps: int = 60
@export var touch_look_sensitivity: float = 0.25 ## degrees per pixel
@export var camera_distance: float = 5.0
