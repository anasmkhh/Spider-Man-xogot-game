extends DirectionalLight3D
## Configures the sun from exported values (mobile-friendly shadow settings).

@export var sun_rotation_degrees: Vector3 = Vector3(-50.0, -35.0, 0.0)
@export var enable_shadows: bool = true
@export var shadow_distance: float = 90.0


func _ready() -> void:
    rotation_degrees = sun_rotation_degrees
    shadow_enabled = enable_shadows
    directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
    directional_shadow_max_distance = shadow_distance
