extends Node3D
## Builds the placeholder test city from primitives: ground, buildings,
## rooftop slabs and a movement-test course near the spawn point.
## Everything is on physics layer 1 ("world").

@export var seed_value: int = 1337
@export var grid_extent: int = 2
@export var cell_size: float = 40.0
@export var min_height: float = 14.0
@export var max_height: float = 55.0
@export var ground_size: float = 600.0

const WORLD_LAYER: int = 1

var _grid_texture: ImageTexture
var _materials: Dictionary = {}


func _ready() -> void:
    _grid_texture = _make_grid_texture()
    _add_box("Ground", Vector3(0.0, -0.5, 0.0), Vector3(ground_size, 1.0, ground_size), Color(0.45, 0.5, 0.45))
    _build_city()
    _build_test_course()


func _build_city() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    for ix in range(-grid_extent, grid_extent + 1):
        for iz in range(-grid_extent, grid_extent + 1):
            if ix == 0 and iz == 0:
                continue # keep the spawn plaza empty
            var footprint := Vector2(rng.randf_range(18.0, 28.0), rng.randf_range(18.0, 28.0))
            var height: float = rng.randf_range(min_height, max_height)
            var tint := Color.from_hsv(rng.randf_range(0.55, 0.65), 0.12, rng.randf_range(0.55, 0.85))
            var center := Vector3(ix * cell_size, height * 0.5, iz * cell_size)
            _add_box("Building_%d_%d" % [ix, iz], center, Vector3(footprint.x, height, footprint.y), tint)
            if rng.randf() < 0.65:
                var slab_height: float = rng.randf_range(2.0, 4.0)
                var slab_size := Vector3(footprint.x * 0.4, slab_height, footprint.y * 0.4)
                var slab_center := Vector3(center.x, height + slab_height * 0.5, center.z)
                _add_box("Rooftop_%d_%d" % [ix, iz], slab_center, slab_size, tint.darkened(0.25))


func _build_test_course() -> void:
    var wood := Color(0.7, 0.5, 0.3)
    var steel := Color(0.6, 0.65, 0.7)
    # Staircase of 1 m steps leading to a 6 m platform.
    for step in range(1, 7):
        _add_box("Step_%d" % step, Vector3(12.0, step * 0.5, -8.0 - step * 3.0),
                Vector3(4.0, step * 1.0, 3.0), steel)
    _add_box("StairTopPlatform", Vector3(12.0, 5.75, -30.0), Vector3(8.0, 0.5, 8.0), steel)
    # Ramp (15 degrees).
    _add_box("Ramp", Vector3(-12.0, 1.4, -10.0), Vector3(6.0, 0.4, 10.0), wood, Vector3(15.0, 0.0, 0.0))
    # Tall wall for future wall-crawl / wall-run tests.
    _add_box("WallTest", Vector3(0.0, 4.0, -30.0), Vector3(16.0, 8.0, 1.0), steel)
    # Crates of different sizes (obstacles).
    var crate_data: Array[Vector4] = [
        Vector4(7.0, 4.0, 1.0, 0.0), Vector4(-7.0, 5.0, 1.5, 0.0),
        Vector4(6.0, 9.0, 2.0, 0.0), Vector4(-6.0, 10.0, 1.0, 0.0),
        Vector4(0.0, 12.0, 1.2, 0.0), Vector4(-9.0, -3.0, 0.8, 0.0)]
    for i in crate_data.size():
        var c: Vector4 = crate_data[i]
        _add_box("Crate_%d" % i, Vector3(c.x, c.z * 0.5, c.y), Vector3(c.z, c.z, c.z), wood)
    # Jump course: 1.5 m pillars with 3 m gaps.
    for i in range(5):
        _add_box("JumpPad_%d" % i, Vector3(-25.0, 0.75, 8.0 + i * 6.0), Vector3(3.0, 1.5, 3.0), wood)


func _add_box(box_name: String, center: Vector3, size: Vector3, color: Color,
        rotation_deg: Vector3 = Vector3.ZERO) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.name = box_name
    body.collision_layer = WORLD_LAYER
    body.collision_mask = 0
    body.position = center
    body.rotation_degrees = rotation_deg

    var shape := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    shape.shape = box_shape
    body.add_child(shape)

    var mesh_instance := MeshInstance3D.new()
    var box_mesh := BoxMesh.new()
    box_mesh.size = size
    mesh_instance.mesh = box_mesh
    mesh_instance.material_override = _get_material(color)
    body.add_child(mesh_instance)

    add_child(body)
    return body


func _get_material(color: Color) -> StandardMaterial3D:
    if _materials.has(color):
        return _materials[color]
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.albedo_texture = _grid_texture
    material.uv1_triplanar = true
    material.uv1_world_triplanar = true
    material.uv1_scale = Vector3(0.25, 0.25, 0.25)
    material.roughness = 0.9
    _materials[color] = material
    return material


func _make_grid_texture() -> ImageTexture:
    var size: int = 64
    var image := Image.create(size, size, true, Image.FORMAT_RGB8)
    image.fill(Color(0.85, 0.85, 0.85))
    var line := Color(0.55, 0.55, 0.55)
    for i in range(size):
        image.set_pixel(i, 0, line)
        image.set_pixel(0, i, line)
    image.generate_mipmaps()
    return ImageTexture.create_from_image(image)
