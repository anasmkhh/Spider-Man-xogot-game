class_name CameraRig
extends Node3D
## Third-person orbit camera. Rig node = yaw, SpringArm3D = pitch + collision,
## Camera3D = child at the end of the arm. Not parented to the player, so the
## player's own rotation never affects the camera.

signal distance_changed(new_distance: float)

@export var target_path: NodePath
@export var target_offset: Vector3 = Vector3(0.0, 1.6, 0.0)

@export_group("Distance")
@export var distance: float = 5.0: set = set_distance
@export var min_distance: float = 2.5
@export var max_distance: float = 14.0
@export var zoom_step: float = 0.8
@export var distance_smoothing: float = 8.0

@export_group("Rotation")
@export var touch_sensitivity: float = 0.25 ## degrees per pixel
@export var stick_sensitivity: float = 140.0 ## degrees per second
@export var invert_y: bool = false
@export_range(-89.0, 0.0) var pitch_min_deg: float = -75.0
@export_range(0.0, 89.0) var pitch_max_deg: float = 30.0
@export var initial_pitch_deg: float = -20.0
@export var rotation_smoothing: float = 25.0

@export_group("Follow")
@export var follow_smoothing: float = 14.0

var _target: Node3D
var _yaw: float = 0.0
var _pitch: float = 0.0

@onready var _arm: SpringArm3D = $SpringArm3D


func _ready() -> void:
    add_to_group("camera_rig")
    if not target_path.is_empty():
        _target = get_node_or_null(target_path) as Node3D
    _yaw = rotation.y
    _pitch = deg_to_rad(initial_pitch_deg)
    _arm.rotation.x = _pitch
    _arm.spring_length = distance
    if _target != null:
        global_position = _target.global_position + target_offset


func _unhandled_input(event: InputEvent) -> void:
    # Desktop testing only: mouse wheel zoom.
    var button := event as InputEventMouseButton
    if button == null or not button.pressed:
        return
    if button.button_index == MOUSE_BUTTON_WHEEL_UP:
        set_distance(distance - zoom_step)
    elif button.button_index == MOUSE_BUTTON_WHEEL_DOWN:
        set_distance(distance + zoom_step)


func _process(delta: float) -> void:
    _read_look_input(delta)
    _update_rotation(delta)
    _update_position(delta)
    _arm.spring_length = lerpf(_arm.spring_length, distance, 1.0 - exp(-distance_smoothing * delta))


func set_target(new_target: Node3D) -> void:
    _target = new_target


func set_distance(value: float) -> void:
    distance = clampf(value, min_distance, max_distance)
    distance_changed.emit(distance)


func apply_settings(settings: GameSettings) -> void:
    touch_sensitivity = settings.touch_look_sensitivity
    set_distance(settings.camera_distance)


func _read_look_input(delta: float) -> void:
    var touch: Vector2 = InputManager.consume_touch_look()
    var stick: Vector2 = InputManager.get_look_stick()
    var touch_rad: float = deg_to_rad(touch_sensitivity)
    var stick_rad: float = deg_to_rad(stick_sensitivity) * delta
    var y_sign: float = 1.0 if invert_y else -1.0

    _yaw -= touch.x * touch_rad + stick.x * stick_rad
    _pitch += (touch.y * touch_rad + stick.y * stick_rad) * y_sign
    _pitch = clampf(_pitch, deg_to_rad(pitch_min_deg), deg_to_rad(pitch_max_deg))


func _update_rotation(delta: float) -> void:
    var weight: float = 1.0 - exp(-rotation_smoothing * delta)
    rotation.y = lerp_angle(rotation.y, _yaw, weight)
    _arm.rotation.x = lerp_angle(_arm.rotation.x, _pitch, weight)


func _update_position(delta: float) -> void:
    if _target == null:
        return
    var goal: Vector3 = _target.global_position + target_offset
    global_position = global_position.lerp(goal, 1.0 - exp(-follow_smoothing * delta))
