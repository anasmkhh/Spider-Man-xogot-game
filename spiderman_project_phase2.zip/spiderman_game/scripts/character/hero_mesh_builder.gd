class_name HeroMeshBuilder
extends RefCounted
## Static helpers that build the small ArrayMesh details of the hero (eye lenses,
## web lines, chest emblem) projected onto an ellipsoid body surface.
## The model faces -Z (Godot forward). All coordinates are local to the node
## that will display the mesh. Results are plain ArrayMesh resources, so they
## cost a handful of draw calls and no textures.

const FRONT: float = -1.0
const BACK: float = 1.0


# ---- Surface projection ------------------------------------------------------

## Point on the front/back of an ellipsoid above (x, y). Returns [position, normal].
static func surface_point(origin: Vector3, radii: Vector3, x: float, y: float,
        facing: float, lift: float) -> Array:
    var t: float = 1.0 - (x * x) / (radii.x * radii.x) - (y * y) / (radii.y * radii.y)
    var z: float = facing * radii.z * sqrt(maxf(t, 0.02))
    var p := Vector3(x, y, z)
    var n: Vector3 = _normal_at(radii, p)
    return [origin + p + n * lift, n]


## Point on an ellipsoid from polar angle a (0 = pole on the facing axis) and
## azimuth b. Returns [position, normal].
static func polar_point(origin: Vector3, radii: Vector3, a: float, b: float,
        facing: float, lift: float) -> Array:
    var dir := Vector3(sin(a) * cos(b), sin(a) * sin(b), facing * cos(a))
    var p: Vector3 = dir * radii
    var n: Vector3 = _normal_at(radii, p)
    return [origin + p + n * lift, n]


static func _normal_at(radii: Vector3, p: Vector3) -> Vector3:
    return Vector3(p.x / (radii.x * radii.x), p.y / (radii.y * radii.y),
            p.z / (radii.z * radii.z)).normalized()


# ---- Triangle helpers --------------------------------------------------------

## Adds a triangle wound clockwise as seen from its normal side (Godot front face).
static func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3,
        na: Vector3, nb: Vector3, nc: Vector3) -> void:
    var face: Vector3 = (b - a).cross(c - a)
    if face.dot(na + nb + nc) > 0.0:
        st.set_normal(na)
        st.add_vertex(a)
        st.set_normal(nc)
        st.add_vertex(c)
        st.set_normal(nb)
        st.add_vertex(b)
    else:
        st.set_normal(na)
        st.add_vertex(a)
        st.set_normal(nb)
        st.add_vertex(b)
        st.set_normal(nc)
        st.add_vertex(c)


static func _add_polygon(st: SurfaceTool, origin: Vector3, radii: Vector3,
        pts: PackedVector2Array, facing: float, lift: float, dome: float) -> void:
    var centroid := Vector2.ZERO
    for i in pts.size():
        centroid += pts[i]
    centroid /= float(pts.size())
    var c: Array = surface_point(origin, radii, centroid.x, centroid.y, facing, lift + dome)
    for i in pts.size():
        var j: int = (i + 1) % pts.size()
        var p0: Array = surface_point(origin, radii, pts[i].x, pts[i].y, facing, lift)
        var p1: Array = surface_point(origin, radii, pts[j].x, pts[j].y, facing, lift)
        _tri(st, c[0], p0[0], p1[0], c[1], p0[1], p1[1])


static func _add_ribbon(st: SurfaceTool, line: Array, width: float, taper_end: float) -> void:
    var count: int = line.size()
    for i in range(count - 1):
        var p0: Vector3 = line[i][0]
        var n0: Vector3 = line[i][1]
        var p1: Vector3 = line[i + 1][0]
        var n1: Vector3 = line[i + 1][1]
        var n: Vector3 = (n0 + n1).normalized()
        var side: Vector3 = (p1 - p0).cross(n).normalized() * width * 0.5
        var w0: float = lerpf(1.0, taper_end, float(i) / float(count - 1))
        var w1: float = lerpf(1.0, taper_end, float(i + 1) / float(count - 1))
        var qa: Vector3 = p0 - side * w0
        var qb: Vector3 = p0 + side * w0
        var qc: Vector3 = p1 + side * w1
        var qd: Vector3 = p1 - side * w1
        _tri(st, qa, qb, qc, n0, n0, n1)
        _tri(st, qa, qc, qd, n0, n1, n1)


static func _ellipse(cx: float, cy: float, rx: float, ry: float, steps: int) -> PackedVector2Array:
    var pts := PackedVector2Array()
    for i in steps:
        var ang: float = TAU * float(i) / float(steps)
        pts.append(Vector2(cx + rx * cos(ang), cy + ry * sin(ang)))
    return pts


# ---- Eye lenses --------------------------------------------------------------

## Angular, down-slanted superhero eye (right-eye shape, x measured from the
## head midline, y from the eye centre line).
static func _eye_shape() -> PackedVector2Array:
    return PackedVector2Array([
        Vector2(0.014, -0.040), Vector2(0.012, 0.004), Vector2(0.034, 0.028),
        Vector2(0.066, 0.046), Vector2(0.092, 0.052), Vector2(0.093, 0.030),
        Vector2(0.080, 0.000), Vector2(0.056, -0.022), Vector2(0.034, -0.040)])


## Two-surface mesh: surface 0 = dark outline, surface 1 = white lens.
## side: +1 right eye (+X), -1 left eye (-X). eye_y is relative to the ellipsoid centre.
static func build_eye_mesh(origin: Vector3, radii: Vector3, eye_y: float, side: float,
        lens_mat: Material, outline_mat: Material) -> ArrayMesh:
    var base: PackedVector2Array = _eye_shape()
    var lens := PackedVector2Array()
    var centroid := Vector2.ZERO
    for i in base.size():
        var q := Vector2(base[i].x * side, base[i].y + eye_y)
        lens.append(q)
        centroid += q
    centroid /= float(lens.size())
    var outline := PackedVector2Array()
    for i in lens.size():
        outline.append(centroid + (lens[i] - centroid) * 1.3)

    var mesh := ArrayMesh.new()
    _commit_polygon(mesh, origin, radii, outline, FRONT, 0.0025, 0.0, outline_mat)
    _commit_polygon(mesh, origin, radii, lens, FRONT, 0.0055, 0.004, lens_mat)
    return mesh


static func _commit_polygon(mesh: ArrayMesh, origin: Vector3, radii: Vector3,
        pts: PackedVector2Array, facing: float, lift: float, dome: float, mat: Material) -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    _add_polygon(st, origin, radii, pts, facing, lift, dome)
    st.commit(mesh)
    mesh.surface_set_material(mesh.get_surface_count() - 1, mat)


# ---- Web pattern -------------------------------------------------------------

## Radial strands plus sagging ring strands around a pole on the front/back axis.
static func build_web_mesh(origin: Vector3, radii: Vector3, facing: float,
        radial_count: int, radial_range: Vector2, ring_angles: PackedFloat32Array,
        sag: float, width: float, lift: float, mat: Material) -> ArrayMesh:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var samples: int = 6
    for k in radial_count:
        var b: float = TAU * float(k) / float(radial_count)
        var radial_line: Array = []
        for i in samples:
            var a: float = lerpf(radial_range.x, radial_range.y, float(i) / float(samples - 1))
            radial_line.append(polar_point(origin, radii, a, b, facing, lift))
        _add_ribbon(st, radial_line, width, 1.0)
    for r in ring_angles.size():
        var ring_a: float = ring_angles[r]
        for k in radial_count:
            var b0: float = TAU * float(k) / float(radial_count)
            var b1: float = TAU * float(k + 1) / float(radial_count)
            var ring_line: Array = []
            for i in samples:
                var t: float = float(i) / float(samples - 1)
                var a2: float = ring_a * (1.0 - sag * sin(PI * t))
                ring_line.append(polar_point(origin, radii, a2, lerpf(b0, b1, t), facing, lift))
            _add_ribbon(st, ring_line, width, 1.0)
    var mesh: ArrayMesh = st.commit()
    mesh.surface_set_material(0, mat)
    return mesh


# ---- Chest emblem (original stylised spider) ---------------------------------

static func _leg_paths() -> Array:
    return [
        PackedVector2Array([Vector2(0.010, 0.030), Vector2(0.040, 0.062), Vector2(0.075, 0.058), Vector2(0.098, 0.030)]),
        PackedVector2Array([Vector2(0.012, 0.018), Vector2(0.048, 0.036), Vector2(0.092, 0.018), Vector2(0.108, -0.012)]),
        PackedVector2Array([Vector2(0.012, 0.004), Vector2(0.050, 0.008), Vector2(0.088, -0.016), Vector2(0.098, -0.050)]),
        PackedVector2Array([Vector2(0.010, -0.012), Vector2(0.040, -0.030), Vector2(0.066, -0.056), Vector2(0.072, -0.085)])]


static func build_emblem_mesh(origin: Vector3, radii: Vector3, center_y: float,
        emblem_scale: float, lift: float, mat: Material) -> ArrayMesh:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var s: float = emblem_scale
    _add_polygon(st, origin, radii, _ellipse(0.0, center_y - 0.014 * s, 0.022 * s, 0.046 * s, 14), FRONT, lift, 0.0)
    _add_polygon(st, origin, radii, _ellipse(0.0, center_y + 0.036 * s, 0.015 * s, 0.017 * s, 12), FRONT, lift, 0.0)
    var legs: Array = _leg_paths()
    for leg_index in legs.size():
        var leg: PackedVector2Array = legs[leg_index]
        for side in [1.0, -1.0]:
            var line: Array = []
            for i in leg.size():
                var p: Vector2 = leg[i]
                line.append(surface_point(origin, radii, p.x * s * side, center_y + p.y * s, FRONT, lift))
            _add_ribbon(st, line, 0.011 * s, 0.35)
    var mesh: ArrayMesh = st.commit()
    mesh.surface_set_material(0, mat)
    return mesh
