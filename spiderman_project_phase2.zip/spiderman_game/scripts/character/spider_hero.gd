class_name SpiderHero
extends Node3D
## Root of the hero visual (scene: spider_hero.tscn). The body is an articulated
## Node3D hierarchy (NO Skeleton3D yet). This script (1) registers the animation
## pivots for future phases and (2) fills the detail meshes (eyes, web, emblem).
## It never touches movement, input or collision.
## Model faces -Z, feet at y = 0, height ~1.8 m (matches the player capsule).

const MAT_BLACK: Material = preload("res://resources/materials/hero_black.tres")
const MAT_WHITE: Material = preload("res://resources/materials/hero_white.tres")

const CHEST_ORIGIN: Vector3 = Vector3.ZERO
const CHEST_RADII: Vector3 = Vector3(0.205, 0.185, 0.125)
const HEAD_ORIGIN: Vector3 = Vector3(0.0, 0.135, 0.0)
const HEAD_RADII: Vector3 = Vector3(0.115, 0.135, 0.125)
const EYE_Y: float = 0.01 ## eye line relative to the head ellipsoid centre

const HEAD: String = "Hips/Torso/Chest/Neck/Head"
const CHEST: String = "Hips/Torso/Chest"

## Pivots a future animation system can rotate.
const PIVOT_PATHS: Dictionary = {
    &"hips": "Hips",
    &"torso": "Hips/Torso",
    &"chest": "Hips/Torso/Chest",
    &"neck": "Hips/Torso/Chest/Neck",
    &"head": "Hips/Torso/Chest/Neck/Head",
    &"left_shoulder": "Hips/Torso/Chest/LeftShoulder",
    &"right_shoulder": "Hips/Torso/Chest/RightShoulder",
    &"left_elbow": "Hips/Torso/Chest/LeftShoulder/LeftElbow",
    &"right_elbow": "Hips/Torso/Chest/RightShoulder/RightElbow",
    &"left_hip": "Hips/LeftHip",
    &"right_hip": "Hips/RightHip",
    &"left_knee": "Hips/LeftHip/LeftKnee",
    &"right_knee": "Hips/RightHip/RightKnee",
    &"left_ankle": "Hips/LeftHip/LeftKnee/LeftAnkle",
    &"right_ankle": "Hips/RightHip/RightKnee/RightAnkle",
}

@export var build_details: bool = true

var _pivots: Dictionary = {}
var _rest_rotations: Dictionary = {}


func _ready() -> void:
    for key in PIVOT_PATHS:
        var pivot := get_node_or_null(NodePath(PIVOT_PATHS[key])) as Node3D
        if pivot == null:
            push_warning("SpiderHero: missing pivot %s" % PIVOT_PATHS[key])
            continue
        _pivots[key] = pivot
        _rest_rotations[key] = pivot.rotation
    if build_details:
        _build_details()


func get_pivot(pivot_name: StringName) -> Node3D:
    return _pivots.get(pivot_name) as Node3D


func reset_pose() -> void:
    for key in _pivots:
        (_pivots[key] as Node3D).rotation = _rest_rotations[key]


func _build_details() -> void:
    _set_mesh(HEAD + "/LeftEyeLens", HeroMeshBuilder.build_eye_mesh(
            HEAD_ORIGIN, HEAD_RADII, EYE_Y, -1.0, MAT_WHITE, MAT_BLACK))
    _set_mesh(HEAD + "/RightEyeLens", HeroMeshBuilder.build_eye_mesh(
            HEAD_ORIGIN, HEAD_RADII, EYE_Y, 1.0, MAT_WHITE, MAT_BLACK))
    _set_mesh(HEAD + "/MaskWeb", HeroMeshBuilder.build_web_mesh(
            HEAD_ORIGIN, HEAD_RADII, HeroMeshBuilder.FRONT, 14, Vector2(0.35, 1.5),
            PackedFloat32Array([0.55, 0.9, 1.25]), 0.12, 0.003, 0.0015, MAT_BLACK))
    _set_mesh(CHEST + "/ChestEmblem", HeroMeshBuilder.build_emblem_mesh(
            CHEST_ORIGIN, CHEST_RADII, 0.06, 1.35, 0.0045, MAT_BLACK))
    _set_mesh(CHEST + "/ChestWebFront", HeroMeshBuilder.build_web_mesh(
            CHEST_ORIGIN, CHEST_RADII, HeroMeshBuilder.FRONT, 12, Vector2(0.5, 1.25),
            PackedFloat32Array([0.75, 0.98, 1.2]), 0.14, 0.004, 0.004, MAT_BLACK))
    _set_mesh(CHEST + "/ChestWebBack", HeroMeshBuilder.build_web_mesh(
            CHEST_ORIGIN, CHEST_RADII, HeroMeshBuilder.BACK, 12, Vector2(0.25, 1.25),
            PackedFloat32Array([0.5, 0.8, 1.05, 1.25]), 0.14, 0.004, 0.004, MAT_BLACK))


func _set_mesh(path: String, mesh: ArrayMesh) -> void:
    var instance := get_node_or_null(NodePath(path)) as MeshInstance3D
    if instance == null:
        push_warning("SpiderHero: missing mesh node %s" % path)
        return
    instance.mesh = mesh
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
