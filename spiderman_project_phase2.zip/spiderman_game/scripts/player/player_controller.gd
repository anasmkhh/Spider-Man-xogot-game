class_name PlayerController
extends CharacterBody3D
## Third-person player controller (walk, run, jump, gravity).
## Reads input ONLY through the InputManager autoload. Movement is relative to
## the active Camera3D. Only the child "CharacterVisualRoot" node rotates, so the collision
## capsule keeps a stable orientation for future wall-crawl / swing states.

signal jumped
signal landed(fall_speed: float)
signal run_state_changed(is_running: bool)
signal state_changed(new_state: State, old_state: State)

enum State { IDLE, WALK, RUN, JUMP, FALL }

@export_group("Movement")
@export var walk_speed: float = 5.0
@export var run_speed: float = 9.5
@export var ground_acceleration: float = 45.0
@export var ground_deceleration: float = 55.0
@export_range(0.0, 1.0) var air_control: float = 0.4
@export var rotation_speed: float = 14.0

@export_group("Jump and Gravity")
@export var jump_velocity: float = 9.0
@export var gravity_multiplier: float = 2.0
@export var max_fall_speed: float = 60.0
@export var coyote_time: float = 0.12
@export var jump_buffer_time: float = 0.12

@export_group("Safety")
@export var kill_height: float = -30.0

var state: State = State.IDLE
var is_running: bool = false

var _gravity: float = 9.8
var _coyote_timer: float = 0.0
var _jump_buffer_timer: float = 0.0
var _was_on_floor: bool = false
var _spawn_transform: Transform3D

@onready var _visual: Node3D = $CharacterVisualRoot


func _ready() -> void:
    _gravity = float(ProjectSettings.get_setting("physics/3d/default_gravity", 9.8))
    _spawn_transform = global_transform
    InputManager.jump_requested.connect(_on_jump_requested)


func _physics_process(delta: float) -> void:
    _update_timers(delta)
    _apply_gravity(delta)
    _try_jump()

    var move_dir: Vector3 = _get_camera_relative_direction()
    _update_running(move_dir)
    _apply_horizontal_movement(move_dir, delta)
    _rotate_visual(move_dir, delta)

    var vertical_before: float = velocity.y
    move_and_slide()

    if is_on_floor() and not _was_on_floor:
        landed.emit(maxf(-vertical_before, 0.0))
    _was_on_floor = is_on_floor()

    _update_state()
    if global_position.y < kill_height:
        respawn()


func respawn() -> void:
    global_transform = _spawn_transform
    velocity = Vector3.ZERO


func get_horizontal_speed() -> float:
    return Vector2(velocity.x, velocity.z).length()


func _on_jump_requested() -> void:
    _jump_buffer_timer = jump_buffer_time


func _update_timers(delta: float) -> void:
    if is_on_floor() and velocity.y <= 0.0:
        _coyote_timer = coyote_time
    else:
        _coyote_timer = maxf(_coyote_timer - delta, 0.0)
    _jump_buffer_timer = maxf(_jump_buffer_timer - delta, 0.0)


func _apply_gravity(delta: float) -> void:
    if not is_on_floor():
        velocity.y = maxf(velocity.y - _gravity * gravity_multiplier * delta, -max_fall_speed)


func _try_jump() -> void:
    if _jump_buffer_timer > 0.0 and _coyote_timer > 0.0:
        velocity.y = jump_velocity
        _jump_buffer_timer = 0.0
        _coyote_timer = 0.0
        jumped.emit()


func _get_camera_relative_direction() -> Vector3:
    var move_input: Vector2 = InputManager.get_move_vector()
    if move_input.length_squared() < 0.0001:
        return Vector3.ZERO

    var forward: Vector3 = Vector3.FORWARD
    var right: Vector3 = Vector3.RIGHT
    var camera: Camera3D = get_viewport().get_camera_3d()
    if camera != null:
        var cam_basis: Basis = camera.global_transform.basis
        var cam_forward: Vector3 = -cam_basis.z
        cam_forward.y = 0.0
        var cam_right: Vector3 = cam_basis.x
        cam_right.y = 0.0
        if cam_forward.length_squared() > 0.0001 and cam_right.length_squared() > 0.0001:
            forward = cam_forward.normalized()
            right = cam_right.normalized()
    return (right * move_input.x - forward * move_input.y).limit_length(1.0)


func _update_running(move_dir: Vector3) -> void:
    var wants_run: bool = InputManager.is_run_held() and move_dir.length_squared() > 0.01
    if wants_run != is_running:
        is_running = wants_run
        run_state_changed.emit(is_running)


func _apply_horizontal_movement(move_dir: Vector3, delta: float) -> void:
    var top_speed: float = run_speed if is_running else walk_speed
    var target: Vector3 = move_dir * top_speed
    var rate: float = ground_acceleration if move_dir.length_squared() > 0.0001 else ground_deceleration
    if not is_on_floor():
        rate *= air_control
    var horizontal := Vector3(velocity.x, 0.0, velocity.z)
    horizontal = horizontal.move_toward(target, rate * delta)
    velocity.x = horizontal.x
    velocity.z = horizontal.z


func _rotate_visual(move_dir: Vector3, delta: float) -> void:
    if move_dir.length_squared() < 0.01:
        return
    var target_yaw: float = atan2(-move_dir.x, -move_dir.z)
    var weight: float = 1.0 - exp(-rotation_speed * delta)
    _visual.rotation.y = lerp_angle(_visual.rotation.y, target_yaw, weight)


func _update_state() -> void:
    var new_state: State = State.IDLE
    if is_on_floor():
        if get_horizontal_speed() < 0.2:
            new_state = State.IDLE
        elif is_running:
            new_state = State.RUN
        else:
            new_state = State.WALK
    elif velocity.y > 0.0:
        new_state = State.JUMP
    else:
        new_state = State.FALL

    if new_state != state:
        var old_state: State = state
        state = new_state
        state_changed.emit(new_state, old_state)
